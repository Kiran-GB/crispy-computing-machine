import React from "react";
import BookActions from './data/BookActions'
import BookStore from './data/BookStore'

export default class NewBook extends React.Component {
    constructor(props) {
        super(props) //since we are extending class Table so we have to use super in order to override Component class constructor
        BookActions.loadBooks()
        this.state = {
                formData: {},
                books: BookStore.getBooks(),
            }

            Object.getOwnPropertyNames(NewBook.prototype).forEach((method) => {
                this[method] = this[method].bind(this);
            });
        }

    handleNameUpdate(event) {
        const { formData } = this.state;
        this.setState({
          formData: Object.assign(formData, { bookname: event.target.value }),
        });
    }

    handleAuthorUpdate(event) {
        const { formData } = this.state;
        this.setState({
            formData: Object.assign(formData, { author: event.target.value }),
        });
    }

  handleSubmit(event) {
    const { formData } = this.state;
    event.preventDefault();
    let newBook =  {name: formData.bookname, author: formData.author} 
    let books = this.state.books;
    books.push(newBook);
    BookActions.updateBooks(books);
  }

  render() {
    if(!this.props.show){
        return null;
    }
    return (
        <div className="modal" id="modal">
            <form onSubmit={this.handleSubmit}>
                <label>
                    Book-Name:
                    <input type="text" name="bookname" onChange={this.handleNameUpdate}/>
                </label>
                <label>
                    Author:
                    <input type="text" name="author" onChange={this.handleAuthorUpdate}/>
                </label>
               
                <input type="submit" value="Submit" />
            </form>
        </div> 
    );
  }
}


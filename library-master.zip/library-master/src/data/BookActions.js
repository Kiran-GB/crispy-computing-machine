import BookActionTypes from './BookActionTypes';
import BookDispatcher from './BookDispatcher';

const BookActions = {

    loadBooks() {
      let books = [
            { name: 'THE GUIDE', author: 'R.K. NARAYAN' },
            { name: 'THE PRIVATE LIFE OF AN INDIAN PRINCE', author: 'MULK RAJ ANAND' },
            { name: 'TRAIN TO PAKISTAN', author: 'KHUSHWANT SINGH' },
            { name: 'THE ROOM ON THE ROOF', author: 'RUSKIN BOND' },
            { name: 'THE COMPLETE ADVENTURES OF FELUDA', author: 'SATYAJIT RAY' },
            { name: 'COMBAT OF SHADOWS', author: 'MANOHAR MALGONKAR' },
            { name: 'THE AUTOBIOGRAPHY OF AN UNKNOWN INDIAN', author: 'NIRAD C. CHAUDHURI' },
            { name: 'THE GOD OF SMALL THINGS', author: 'ARUNDHATI ROY' },
            { name: 'MALGUDI DAYS', author: 'R.K. NARAYAN' },
            { name: 'THE WHITE TIGER', author: 'ARAVIND ADIGA' }
         ]

         BookDispatcher.dispatch({
            actionType: BookActionTypes.INIT_BOOKS,
            books: books,
          });

         
     },  

  updateBooks(books) {
      console.log('calling actions...', books);
    BookDispatcher.dispatch({
        actionType: BookActionTypes.UPDATE_BOOKS,
      books: books,
      
    });
    console.log('dispatching', books);
  },
};

export default BookActions;

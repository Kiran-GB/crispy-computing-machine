const BookActionTypes = {
    INIT_BOOKS: 'INIT_BOOKS',
    UPDATE_BOOKS: 'UPDATE_BOOKS',
  };
  
  export default BookActionTypes;
